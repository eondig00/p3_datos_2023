package ule.ed.list;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

import org.junit.*;


public class CircularDoubleLinkedListTest {
	private CircularDoubleWithHeaderList<String> lista;
	
	@Before
	public void setUp() {
		 lista= new CircularDoubleWithHeaderList<String>();
	}

	@Test
	public void DoubleLinked_VaciaTest() {
		assertEquals(0,lista.size());
		assertTrue(lista.isEmpty());
	}
	
	// test addFirst comprueba que dispara excepción
	@Test(expected=NullPointerException.class)
	public void DoubleLinked_AddFirstElementoNuloTest() {
			lista.addFirst(null);
	}
	
	@Test
	public void DoubleLinked_AddFirstTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
	}
	

	//test de iteradores
	@Test
	public void DoubleLinked_IteratorTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		Iterator<String>  iter=lista.iterator();
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("3", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertFalse(iter.hasNext());
	}
	
	@Test
	public void DoubleLinked_ReverseIteratorTest() {
		lista.addFirst("2");
		Assert.assertFalse(lista.isEmpty());
		Assert.assertEquals("(2 )", lista.toString());
		lista.addFirst("3");
		Assert.assertEquals("(3 2 )", lista.toString());
		lista.addFirst("7");
		Assert.assertEquals("(7 3 2 )", lista.toString());
		Iterator<String>  iter=lista.iteratorReverse();
		assertTrue(iter.hasNext());
		assertEquals("2", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("3", iter.next());
		assertTrue(iter.hasNext());
		assertEquals("7", iter.next());
		assertFalse(iter.hasNext());
	}
	
	
	
	
	// TEST ITERADORES EN LISTA VACÍA
	@Test(expected=NoSuchElementException.class)
	public void DoubleLinkedNextListaVaciaTest() {
			lista.iterator().next();	}
	
	
	//TEST reverse
	@Test
	public void DoubleLinked_toStringReverseTest() {
	
	lista.addFirst("6");
	Assert.assertFalse(lista.isEmpty());
	Assert.assertEquals("(6 )", lista.toString());
	lista.addFirst("5");
	Assert.assertEquals("(5 6 )", lista.toString());
	lista.addFirst("4");
	Assert.assertEquals("(4 5 6 )", lista.toString());
	lista.addFirst("4");
	Assert.assertEquals("(4 4 5 6 )", lista.toString());
	Assert.assertEquals("(6 5 4 4 )", lista.toStringReverse());
	Assert.assertEquals("(4 4 5 6 )", lista.toString()); // queda en el mismo estado
	
	}
	
	//resto TESTS

	@Test
	public void DoubleLinked_SizeTest() {
	    assertEquals(0, lista.size());
	    lista.addFirst("2");
	    assertEquals(1, lista.size());
	    lista.addFirst("3");
	    assertEquals(2, lista.size());
	    lista.addFirst("7");
	    assertEquals(3, lista.size());
	}

	@Test
	public void DoubleLinked_IsEmptyTest() {
	    assertTrue(lista.isEmpty());
	    lista.addFirst("2");
	    assertFalse(lista.isEmpty());
	}

	@Test
	public void addLastTest() {
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");
		assertEquals("A", lista.getElemPos(1));
		assertEquals("B", lista.getElemPos(2));
		assertEquals("C", lista.getElemPos(3));
	}
	
	@Test
	public void addFirstTest() {
		lista.addFirst("A");
		lista.addFirst("B");
		lista.addFirst("C");
		assertEquals("C", lista.getElemPos(1));
		assertEquals("B", lista.getElemPos(2));
		assertEquals("A", lista.getElemPos(3));
	}

	@Test(expected = NullPointerException.class)
	public void addLastNullTest() {
		lista.addLast(null);
	}
	
	@Test
	public void addPosTest() {
		lista.addPos("A", 1);
		lista.addPos("B", 2);
		lista.addPos("C", 3);
		lista.addPos("D", 2);
		assertEquals("A", lista.getElemPos(1));
		assertEquals("D", lista.getElemPos(2));
		assertEquals("B", lista.getElemPos(3));
		assertEquals("C", lista.getElemPos(4));
	}
	
	@Test(expected = NullPointerException.class)
	public void addPosNullTest() {
		lista.addPos(null, 0);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void addPosInvalidPositionTest() {
		lista.addPos("A", -1);
	}
	
	@Test
	public void addPosPositionGreaterThanSizeTest() {
		lista.addPos("A", 1);
		lista.addPos("B", 2);
		lista.addPos("C", 3);
		lista.addPos("D", 10);
		assertEquals("A", lista.getElemPos(1));
		assertEquals("B", lista.getElemPos(2));
		assertEquals("C", lista.getElemPos(3));
		assertEquals("D", lista.getElemPos(4));
	}
	
	@Test
	public void removeFirstTest() throws EmptyCollectionException {
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("C");
		assertEquals("A", lista.removeFirst());
		assertEquals("B", lista.getElemPos(1));
		assertEquals("C", lista.getElemPos(2));
	}
	
	@Test(expected = EmptyCollectionException.class)
	public void removeFirstEmptyListTest() throws EmptyCollectionException {
		lista.removeFirst();
	}
	
	@Test
    public void testAddLast() {
        lista.addLast("A");
        assertEquals(1, lista.size());
        lista.addLast("B");
        assertEquals(2, lista.size());
        lista.addLast("C");
        assertEquals(3, lista.size());
        assertEquals("A", lista.getElemPos(1));
        assertEquals("B", lista.getElemPos(2));
        assertEquals("C", lista.getElemPos(3));
    }

    @Test
    public void testAddPos() {
        lista.addPos("A", 1);
        assertEquals(1, lista.size());
        lista.addPos("B", 2);
        assertEquals(2, lista.size());
        lista.addPos("C", 3);
        assertEquals(3, lista.size());
        lista.addPos("D", 4);
        assertEquals(4, lista.size());
        assertEquals("A", lista.getElemPos(1));
        assertEquals("D", lista.getElemPos(4));
        assertEquals("B", lista.getElemPos(2));
        assertEquals("C", lista.getElemPos(3));
    }

    @Test
    public void testRemoveFirst() throws EmptyCollectionException {
        lista.addLast("A");
        lista.addLast("B");
        lista.addLast("C");
        assertEquals(3, lista.size());
        assertEquals("A", lista.removeFirst());
        assertEquals(2, lista.size());
        assertEquals("B", lista.removeFirst());
        assertEquals(1, lista.size());
        assertEquals("C", lista.removeFirst());
        assertTrue(lista.isEmpty());
    }

	@Test
	public void testCountElem() {
		lista.addLast("A");
		lista.addLast("B");
		lista.addLast("A");
		lista.addLast("C");
		lista.addLast("B");
		lista.addLast("D");
		lista.addLast("A");
		assertEquals(3, lista.countElem("A"));
	}
	
	@Test
	public void testIteratorReverse() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
        
		Iterator<String> it = lista.iteratorReverse();
		assertTrue(it.hasNext());
		assertEquals("E", it.next());
		assertTrue(it.hasNext());
		assertEquals("D", it.next());
		assertTrue(it.hasNext());
		assertEquals("C", it.next());
		assertTrue(it.hasNext());
		assertEquals("B", it.next());
		assertTrue(it.hasNext());
		assertEquals("A", it.next());
		assertFalse(it.hasNext());
	}

	@Test
	public void testFromUntilIterator() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		//A B C D E
		Iterator<String> it = lista.fromUntilIterator(2, 4);
		assertTrue(it.hasNext());
		assertEquals("B", it.next());
		assertTrue(it.hasNext());
		assertEquals("C", it.next());
		assertTrue(it.hasNext());
		assertEquals("D", it.next());
		assertFalse(it.hasNext());
		it = lista.fromUntilIterator(-1, -2);
		assertTrue(it.hasNext());
		assertEquals("E", it.next());
		assertTrue(it.hasNext());
		assertEquals("D", it.next());
		assertFalse(it.hasNext());
		// Test negativo
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromUntilIteratorException1() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		lista.fromUntilIterator(0, 4);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromUntilIteratorException2() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		lista.fromUntilIterator(2, 0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromUntilIteratorException3() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		lista.fromUntilIterator(-2, 4);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testFromUntilIteratorException4() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		lista.fromUntilIterator(4, -2);
	}

	@Test
	public void testGetElemPos() {
		lista.addFirst("E");
        lista.addFirst("D");
        lista.addFirst("C");
        lista.addFirst("B");
        lista.addFirst("A");
		assertEquals("A", lista.getElemPos(1));
		assertEquals("C", lista.getElemPos(3));
		assertEquals("E", lista.getElemPos(-1));
		assertEquals("D", lista.getElemPos(-2));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetElemPosException1() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		lista.getElemPos(0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetElemPosException2() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		lista.getElemPos(10);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testGetElemPosException3() {
		lista.addPos("A", 1);
        lista.addPos("B", 2);
        lista.addPos("C", 3);
        lista.addPos("D", 4);
        lista.addPos("E", 5);
		lista.getElemPos(-10);
	}

	@Test
	public void testRemovePosLast() throws EmptyCollectionException {
        lista.addPos("E", 1);
        lista.addPos("D", 2);
        lista.addPos("C", 3);
        lista.addPos("B", 4);
		lista.addPos("A", 5);
		assertEquals(5, lista.removePosLast("A"));
		assertEquals(4, lista.removePosLast("B"));
	}

	@Test(expected = EmptyCollectionException.class)
	public void testRemovePosLastException1() throws EmptyCollectionException {
		CircularDoubleWithHeaderList<String> emptyList = new CircularDoubleWithHeaderList<String>();
		emptyList.removePosLast("A");
	}

	@Test(expected = NullPointerException.class)
	public void testRemovePosLastException2() throws EmptyCollectionException {
		lista.addPos("E", 1);
	    lista.addPos("D", 2);
	    lista.addPos("C", 3);
		lista.removePosLast(null);
	}

	@Test(expected = NoSuchElementException.class)
	public void testRemovePosLastException3() throws EmptyCollectionException {
		lista.addPos("E", 1);
	    lista.addPos("D", 2);
	    lista.addPos("C", 3);
	    lista.addPos("B", 4);
		lista.addPos("A", 5);
		lista.removePosLast("Z");
	}
	
	@Test
    public void testRemovelast() throws EmptyCollectionException {
		lista.addFirst("A");
        lista.addFirst("B");
        lista.addLast("C");
		lista.removelast();
        assertEquals(2, lista.size());
    }

    @Test(expected = EmptyCollectionException.class)
    public void testRemovelastEmpty() throws EmptyCollectionException {
    	CircularDoubleWithHeaderList<String> emptyList = new CircularDoubleWithHeaderList<>();
        emptyList.removelast();
    }

    @Test
    public void testRemoveElem() throws EmptyCollectionException {
    	lista.addFirst("A");
        lista.addFirst("B");
        lista.addLast("C");
        lista.addLast("E");
        lista.addLast("D");
    	assertEquals(3, lista.removeElem("C"));
        assertEquals(4, lista.size());
    }

    @Test(expected = EmptyCollectionException.class)
    public void testRemoveElemEmpty() throws EmptyCollectionException {
    	CircularDoubleWithHeaderList<String> emptyList = new CircularDoubleWithHeaderList<>();
        emptyList.removeElem("A");
    }

    @Test(expected = NullPointerException.class)
    public void testRemoveElemNull() throws EmptyCollectionException {
        lista.removeElem(null);
    }

    @Test(expected = NoSuchElementException.class)
    public void testRemoveElemNotFound() throws EmptyCollectionException {
    	 lista.addFirst("C");
         lista.addFirst("B");
         lista.addFirst("A");
    	lista.removeElem("D");
    }
    
    @Test
    public void testFromUntilIncluded() {
    	CircularDoubleWithHeaderList<String> list;
         list = new CircularDoubleWithHeaderList<>();
        list.addFirst("A");
        list.addPos("B", 2);
        list.addPos("C", 3);
        list.addPos("D", 4);
        list.addPos("E", 5);

        // Test valid range
        assertEquals("(A B C )", list.fromUntilIncluded(1, 3));
        assertEquals("(C D E )", list.fromUntilIncluded(3, 10));

        // Test range beyond the end of the list
        assertEquals("()", list.fromUntilIncluded(10, 20));
        
     // Test negativo
        assertEquals("(E D )", list.fromUntilIncluded(-1, -2));
        assertEquals("(E D C )", list.fromUntilIncluded(-1, -3));
        assertEquals("(E D C B A )", list.fromUntilIncluded(-1,-10));
        assertEquals("(B A )", list.fromUntilIncluded(-4,-10));
    }
	    
	@Test
	public void DoubleLinked_IntersecTest() {
		IDoubleNotOrderedList<String> lista1 = new CircularDoubleWithHeaderList<String>();
		lista1.addLast("A");
		lista1.addLast("B");
		lista1.addLast("C");
		lista1.addLast("B");
		lista1.addLast("D");
		lista1.addLast("A");
		lista1.addLast("B");
    	IDoubleNotOrderedList<String> lista2 = new CircularDoubleWithHeaderList<String>();
		lista2.addLast("Z");
		lista2.addLast("B");
		lista2.addLast("A");
		lista2.addLast("B");
		lista2.addLast("A");
		lista2.addLast("K");
		lista2.addLast("A");
			
		IDoubleNotOrderedList<String> intersecLista = lista1.intersec(lista2);
			
		Assert.assertFalse(intersecLista.isEmpty());
		Assert.assertEquals(4, intersecLista.size());
		Assert.assertEquals("(A A B B )", intersecLista.toString());
			
		IDoubleNotOrderedList<String> lista3 = new CircularDoubleWithHeaderList<String>();
		lista3.addLast("A");
		lista3.addLast("B");
		lista3.addLast("C");
		lista3.addLast("B");
		lista3.addLast("D");
		lista3.addLast("A");
		lista3.addLast("B");
			
		IDoubleNotOrderedList<String> lista4 = new CircularDoubleWithHeaderList<String>();
		lista4.addLast("Z");
		lista4.addLast("L");
		lista4.addLast("K");
			
		IDoubleNotOrderedList<String> intersecLista2 = lista3.intersec(lista4);
			
		Assert.assertTrue(intersecLista2.isEmpty());
		Assert.assertEquals(0, intersecLista2.size());
		IDoubleNotOrderedList<String> lista5 = new DoubleLinkedList<String>();
		IDoubleNotOrderedList<String> lista6 = new DoubleLinkedList<String>();
			
		IDoubleNotOrderedList<String> intersecLista3 = lista5.intersec(lista6);
			
		Assert.assertTrue(intersecLista3.isEmpty());
		Assert.assertEquals(0, intersecLista3.size());
	}

}

		
				
