package ule.ed.list;

import static org.junit.Assert.assertNotNull;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoubleLinkedList<T> implements IDoubleNotOrderedList<T>{

    //	referencias al primer y al último nodo de la lista
    // la lista vacía debe tener front y last apuntando a null
    private DoubleNode<T> front;
    private DoubleNode<T> last;

    // NO SE PUEDEN AÑADIR MÁS ATRIBUTOS A LA LISTA

    private class DoubleNode<T> {

        DoubleNode(T element) {
            this.elem = element;
            this.next = null;
            this.prev = null;
        }

        T elem;

        DoubleNode<T> next;
        DoubleNode<T> prev;
    }




    // CLASE DEL ITERADOR NORMAL
    private class DoubleList_Iterator<T> implements Iterator<T> {
        private DoubleNode<T> current;

        public DoubleList_Iterator(DoubleNode<T> aux) {
            current = aux;
        }

        @Override
        public boolean hasNext() {
            return (current != null);
        }

        @SuppressWarnings("unchecked")
        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            T result = current.elem;
            current = current.next;
            return result;
        }
    }

    /// TODO :  AÑADIR OTRAS CLASES PARA LOS OTROS ITERADORES
    private class DoubleLinkedListFromUntilIterator<T> implements Iterator<T> {
        private DoubleNode<T> current;
        int from, until, count;

        public  DoubleLinkedListFromUntilIterator(int from, int until, DoubleNode<T> front, DoubleNode<T> last) {
            if (from < 0 && until < 0) {
                count = -1;
                current = last;
                this.from = from;
                this.until = until;

                while (count > from) {
                    current = current.prev;
                    count--;
                }
            } else if (from > 0 && until > 0) {
                count = 1;
                current = front;
                this.from = from;
                this.until = until;

                while (count < from) {
                    current = current.next;
                    count++;
                }
            } else {
                throw new IllegalArgumentException();
            }
        }

        public boolean hasNext() {
            if (until > 0) {
                return current != null && (count <= until);
            }
            return current != null && count >= until;
        }

        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T elem = null;

            if (from > 0) {
                elem = current.elem;
                current = current.next;
                count++;
            } else {
                elem = current.elem;
                current = current.prev;
                count--;
            }
            return elem;
        }
    }


    private class DoubleLinkedListReverseIterator<T> implements Iterator<T> {
        private DoubleNode<T> current;

        public DoubleLinkedListReverseIterator(DoubleNode<T> aux) {
            current = aux;
        }

        @Override
        public boolean hasNext() {
            return (current != null);
        }

        @SuppressWarnings("unchecked")
        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            T result = current.elem;
            current = current.prev;
            return result;
        }
    }
    // FIN ITERADORES


    @Override
    public int size() {
        int size = 0;
        DoubleNode<T> current = front;

        while (current != null) {
            current = current.next;
            size++;
        }
        return size;
    }

    @Override
    public boolean isEmpty() {
        return (front == null && last == null);
    }

    @Override
    public void addFirst(T elem) {
        if(elem == null) {
            throw new NullPointerException();
        }

        DoubleNode <T> nuevo = new DoubleNode<T>(elem);

        if(isEmpty()) {
            nuevo.prev = front;
            front = nuevo;
            last = nuevo;
            nuevo.next = null;
        }	else {
            nuevo.next = front;
            front.prev = nuevo;
            front = nuevo;
            nuevo.prev = null;
        }
    }

    @Override
    public void addLast(T elem) {
        DoubleNode<T> node = new DoubleNode<T>(elem);

        if (elem == null) {
            throw new NullPointerException();
        } else if (isEmpty()) {
            addFirst(elem);
        } else {
            DoubleNode<T> aux = front;
            while (aux.next != null) {
                aux = aux.next;
            }
            aux.next = node;
            node.prev = aux;
            last = node;
        }

    }


    @Override
    public void addPos(T elem, int position) {
        if (elem == null) {
            throw new NullPointerException();
        }

        if (position <= 0) {
            throw new IllegalArgumentException();
        }

        DoubleNode<T> node = new DoubleNode<>(elem);

        if (position == 1) {
            addFirst(elem);
            return;
        }

        if (position > size()) {
            addLast(elem);
            return;
        }

        DoubleNode<T> aux = front;
        for (int i = 1; i < position - 1; i++) {
            if (aux == null) {
                throw new IllegalArgumentException();
            }
            aux = aux.next;
        }
        if (aux == null) {
            throw new IllegalArgumentException();
        }

        node.next = aux.next;
        aux.next = node;
        node.prev = aux;
    }


    @Override
    public T removeFirst() throws EmptyCollectionException {
        T result = null;

        if (isEmpty()) {
            throw new EmptyCollectionException("SET");
        }

        if (size() == 1) {
            result = front.elem;
            front = null;
            last = null;
            return result;
        }

        result = front.elem;
        front = front.next;
        front.prev = null;
        //front.next.prev = front;
        return result;
    }


    @Override
    public T removelast() throws EmptyCollectionException {
        T result = null;

        if (isEmpty()) {
            throw new EmptyCollectionException("SET");
        }
        if (size() == 1) {
            result = removeFirst();
        } else {
            result = last.elem;
            last = last.prev;
            last.next = null;
        }
        return result;
    }


    @Override
    public int removeElem(T elem) throws EmptyCollectionException {
        if(elem == null) throw new NullPointerException();
        if(isEmpty()) {
            throw new EmptyCollectionException("SET");
        }

        int cont = 1, position = 0;
        DoubleNode<T> aux = front;

        while (aux != null) {
            if (aux.elem.equals(elem)) {
                position = cont;
                break;
            }
            cont++;
            aux = aux.next;
        }

        if (position == 0) {
            throw new NoSuchElementException();
        }

        if (position == 1) {
            removeFirst();
        } else if (position == size()) {
            removelast();
        } else {
            aux = front;
            while (aux != null) {
                if (aux.elem.equals(elem)) {
                    break;
                }
                aux = aux.next;

            }
            aux.prev.next = aux.next;
            aux.next.prev = aux.prev;
        }
        return position;
    }


    @Override
    public T getElemPos(int position) {
        DoubleNode<T> aux;
        T result = null;
        int cont;

        if (position == 0 || position > size() || position < -size()) {
            throw new IllegalArgumentException();
        }

        if (position > 0 ) {
            aux = front;
            cont = 1;

            while (cont < position) {
                aux = aux.next;
                cont++;
            }
        } else {
            aux = last;
            cont = -1;

            while (cont > position) {
                aux = aux.prev;
                cont--;
            }
        }
        result = aux.elem;

        return result;
    }


    @Override
    public int removePosLast(T elem) throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("SET");
        }
        if (elem == null) {
            throw new NullPointerException();
        }

        int lastPosition = 0, i = 1;
        DoubleNode<T> aux = front;

        while (aux != null) {
            if (aux.elem.equals(elem)) {
                lastPosition = i;
            }
            i++;
            aux = aux.next;
        }

        if (lastPosition == 0) {
            throw new NoSuchElementException();
        }


        if(lastPosition == 1) {
            removeFirst();
        } else if(lastPosition == size()) {
            removelast();
        } else {
            aux = front;
            int j = 1;

            while(j < lastPosition) {
                aux = aux.next;
                j++;
            }

            aux.prev.next = aux.next;
            aux.next.prev = aux.prev;
        }
        return lastPosition;
    }


    @Override
    public int countElem(T elem) {
        if (elem == null)
            throw new NullPointerException();

        int cont = 0;
        int i = 0;

        DoubleNode<T> aux = front;
        while (aux != null) {
            if (aux.elem.equals(elem)) {
                cont++;
            }
            i++;
            aux = aux.next;
        }
        return cont;
    }


    @Override
    public IDoubleNotOrderedList<T> intersec(IDoubleNotOrderedList<T> other) {
        DoubleLinkedList<T> result = new DoubleLinkedList<>();
        DoubleNode <T> aux = front;

        if(this.isEmpty() || other.isEmpty()) {
            return result;
        }

        while(aux != null) {
            T elem = aux.elem;
            if (result.countElem(elem) == 0) {
                int minimun, cont = 0;

                if(this.countElem(elem) < other.countElem(elem)) {
                    minimun = this.countElem(elem);
                } else {
                    minimun = other.countElem(elem);
                }

                while (cont < minimun) {
                    result.addLast(elem);
                    cont++;
                }
            }
            aux = aux.next;
        }
        return result;
    }


    @Override
    public String fromUntilIncluded(int from, int until) {
        StringBuilder builder = new StringBuilder();

        int position = from;

        if (from == 0 || until == 0) {
            throw new IllegalArgumentException("ERROR");
        } else if (from > 0 && until > 0) {
            DoubleNode<T> aux = front;

            if (from > this.size()) {
                builder.append("()");
            } else if (until > this.size()) {
                int auxCount = 1;

                while (auxCount < from) {
                    aux = aux.next;
                    auxCount++;
                }

                builder.append("(");
                while (aux != null && position <= until) {
                    builder.append(aux.elem + " ");
                    aux = aux.next;
                    position++;
                }
                builder.append(")");
            } else {
                int auxCount = 1;

                while (auxCount < from) {
                    aux = aux.next;
                    auxCount++;
                }

                builder.append("(");
                while (position <= until) {
                    builder.append(aux.elem + " ");
                    aux = aux.next;
                    position++;
                }
                builder.append(")");
            }
        } else if (from < 0 && until < 0) {
            DoubleNode<T> aux = last;
            if (from < -this.size() + 1) {
                builder.append("()");
            } else if (until < -this.size() + 1) {
                int auxCount = -1;

                while (auxCount > from) {

                    aux = aux.prev;
                    auxCount--;
                }
                builder.append("(");
                while (aux != null && position >= until) {
                    builder.append(aux.elem + " ");
                    aux = aux.prev;
                    position--;
                }
                builder.append(")");
            } else {
                int auxCount = -1;

                while (auxCount > from) {

                    aux = aux.prev;
                    auxCount--;
                }

                builder.append("(");
                while (position >= until && aux != null) {
                    builder.append(aux.elem + " ");
                    aux = aux.prev;
                    position--;
                }
                builder.append(")");
            }
        } else {
            throw new IllegalArgumentException();
        }

        return builder.toString();

    }


    @Override
    public Iterator<T> iterator() {
        return  new DoubleList_Iterator<T>(front);
    }


    @Override
    public Iterator<T> iteratorReverse() {
        return new DoubleLinkedListReverseIterator<T>(last);
    }


    @Override
    public Iterator<T> fromUntilIterator(int from, int until) {
        return new DoubleLinkedListFromUntilIterator(from, until, front, last);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("(");

        DoubleNode<T> current = front;

        while (current != null) {
            sb.append(current.elem);
            sb.append(" ");
            current = current.next;
        }

        sb.append(")");

        return sb.toString();
    }

    @Override
    public String toStringReverse() {
        DoubleLinkedList<T> reversedList = new DoubleLinkedList<T>();
        DoubleNode<T> aux = front;
        while (aux != null) {
            reversedList.addFirst(aux.elem);
            aux = aux.next;
        }
        return reversedList.toString();
    }

}	