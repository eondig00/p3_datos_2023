package ule.ed.list;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class CircularDoubleWithHeaderList<T> implements IDoubleNotOrderedList<T> {
	// NO SE PUEDEN AÑADIR MÁS ATRIBUTOS A LA LISTA

	//	referencia al nodo cabecera : único nodo cuyo elem es null
	DoubleNode<T> header;
	 
		private class DoubleNode<T> {

			DoubleNode(T element) {
				this.elem = element;
				this.next = null;
				this.prev = null;
			}

			T elem;

			DoubleNode<T> next;
			DoubleNode<T> prev;
		}
		
   
    
	
	// CLASE DEL ITERADOR NORMAL 
	private class CircularDoubleList_Iterator<T> implements Iterator<T> {
		private DoubleNode<T> current;
		
		public CircularDoubleList_Iterator(DoubleNode<T> aux) {
			current = aux.next;
		}
		
		@Override
		public boolean hasNext() {
			return (current != header);
		}

		@SuppressWarnings("unchecked")
		@Override
		public T next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}

			T result = current.elem;
			current = current.next;
			return result;
		}
	}
	
	/// TODO :  AÑADIR OTRAS CLASES PARA LOS OTROS ITERADORES
	private class CircularDoubleList_FromUntilIterator<T> implements Iterator<T> {
			private DoubleNode<T> currentNode;
	        int from, until, currentIndex;

	        public  CircularDoubleList_FromUntilIterator(int from, int until, DoubleNode<T> header) {
	            if (from < 0 && until < 0) {
	            	currentIndex = -1;
	                currentNode = header.prev;
	                this.from = from;
	                this.until = until;

	                while (currentIndex > from) {
	                	currentNode = currentNode.prev;
	                	currentIndex--;
	                }
	            } else if (from > 0 && until > 0) {
	            	currentIndex = 1;
	                currentNode = header.next;
	                this.from = from;
	                this.until = until;

	                while (currentIndex < from) {
	                    currentNode = currentNode.next;
	                    currentIndex++;
	                }
	            } else {
	                throw new IllegalArgumentException();
	            }
	        }

				public boolean hasNext() {
					if (until > 0) {
						return currentNode != header && (currentIndex <= until);
					}
					return currentNode != header && currentIndex >= until;
				}

				public T next() {
					if (!hasNext()) {
						throw new NoSuchElementException();
					}
					T elem = null;
					
					if (until > 0) {
						elem = currentNode.elem;
						currentNode = currentNode.next;
						currentIndex++;
					}
					if(until < 0) {
						elem = currentNode.elem;
						currentNode = currentNode.prev;
						currentIndex--;
					}
				return elem;
				}
		}
	
	private class CircularDoubleList_ReverseIterator<T> implements Iterator<T> {
		private DoubleNode<T> current;
		
		public CircularDoubleList_ReverseIterator(DoubleNode<T> aux) {
			current = aux.prev;
		}
		
		@Override
		public boolean hasNext() {
			return (current != header);
		}

		@SuppressWarnings("unchecked")
		@Override
		public T next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}

			T result = current.elem;
			current = current.prev;
			return result;
		}
	}
	
	
	// FIN ITERADORES
	//////////////////////

	// CONSTRUCTOR
	public CircularDoubleWithHeaderList() {
		header = new DoubleNode<T>(null);
		header.prev = header;
		header.next = header;
  	}
  
	@Override
	public int size() {
		int size = 0;
		DoubleNode<T> aux;
		
		aux = header.next;
		
		while(aux != header) {
			aux = aux.next;
			size++;
		}
		
		return size;
	}

	@Override
	public boolean isEmpty() {	
		return (size() == 0);
	}

    @Override
	    public void addFirst(T elem) {
	        if(elem == null) {
	            throw new NullPointerException();
	        }

	        DoubleNode <T> nuevo = new DoubleNode<T>(elem);

	        if(isEmpty()) {
	            header.next = nuevo;
	            header.prev = nuevo;
	            nuevo.prev = header;
	            nuevo.next = header;
	        }	else {
	            nuevo.next = header.next;
	            nuevo.prev = header;
	            header.next.prev = nuevo;
	            header.next = nuevo;
	        }
	}


	@Override
	public void addLast(T elem) {
		if(elem == null) {
			throw new NullPointerException();
		}
		
		if(isEmpty())
			addFirst(elem);
		else {
	        DoubleNode <T> nuevo = new DoubleNode(elem);

	        nuevo.prev = header.prev;
	        nuevo.next = header;
	        header.prev.next = nuevo;
	        header.prev = nuevo;
	    }
	}


	@Override
	public void addPos(T elem, int position) {
		if (elem == null) {
	        throw new NullPointerException();
	    }
	
	    if (position <= 0) {
	        throw new IllegalArgumentException();
	    }
	
	    DoubleNode<T> node = new DoubleNode<>(elem);
	
	    if (position == 1) {
	    	addFirst(elem);
	        return;
	    }
	    
	    if (position > size()) {
	    	addLast(elem);
	    	return;
	    }
	
	    DoubleNode<T> aux = header.next;
	    for (int i = 1; i < position - 1; i++) {
	        if (aux == header) {
	            throw new IllegalArgumentException();
	        }
	        aux = aux.next;
	    }
	    if (aux == header) {
	        throw new IllegalArgumentException();
	    }
	
	    node.next = aux.next;
	    aux.next = node;
	    node.prev = aux;
	}


	@Override
	public T removeFirst() throws EmptyCollectionException {
		T result = null;

		if (isEmpty()) {
			throw new EmptyCollectionException("SET");
		}
		if (size() == 1) {
			result = header.next.elem;
			header.next = header;
			header.prev = header;
			return result;
		}
		
		result = header.next.elem;
		header.next = header.next.next;
		header.next.prev = header;
		return result;
	}


	@Override
	public T removelast() throws EmptyCollectionException {
        T result = null;
    
        if (isEmpty()) {
            throw new EmptyCollectionException("SET");
        }
        if (size() == 1) {
            result = header.prev.elem;
            header.prev = header;
            header.next = header;
        } else {
            result = header.prev.elem;
            header.prev.prev.next = header;
            header.prev = header.prev.prev;
        }

        return result;
	}


	@Override
	public int removeElem(T elem) throws EmptyCollectionException {
		// TODO Auto-generated method stub
		if(elem == null) throw new NullPointerException();
		if(isEmpty()) {
			throw new EmptyCollectionException("SET");
		}
		
		int contador = 0;
		boolean found = false;
		DoubleNode<T> aux = header.next;
		 
		if( aux.next == null ) {
			if(elem.equals(aux.elem)) {
				header.next = header.next.next;
				header.next.prev = header;
				found = true;
			}
		} else {
			if(elem.equals(header.next.elem)) {
				contador++;
				found = true;
				removeFirst();
			} else {
				contador++;
				while(aux.next != header && !found) {
					if(elem.equals(aux.next.elem)) {
						aux.next.prev = aux.prev;
						aux.next = aux.next.next;
						found = true;
					} else {
						aux = aux.next;
					}
					contador++;
				}
			}
		}
		if (!found) throw new NoSuchElementException();
		return contador;
	}


	@Override
	public T getElemPos(int position) {
		T result = null;
		if (position == 0 || position > size() || position < -size()) {
	        throw new IllegalArgumentException();
	    }
		if (position > 0) {
	        DoubleNode<T> aux = header.next;
	        for (int i = 1; i < position; i++) {
	            aux = aux.next;
	        }
	        return aux.elem;
	    } else {
	        DoubleNode<T> aux = header.prev;
	        for (int i = -1; i > position; i--) {
	            aux = aux.prev;
	        }
	        return aux.elem;
	    }
	}


	@Override
	public int removePosLast(T elem) throws EmptyCollectionException {
		if (isEmpty()) {
            throw new EmptyCollectionException("SET");
        }
        if (elem == null) {
            throw new NullPointerException();
        }
        
        int lastPosition = 0;
        int i = 1;
        DoubleNode<T> aux = header.next;
        while (aux != header) {
            if (aux.elem.equals(elem)) {
                    lastPosition = i;
            }
            i++;
            aux = aux.next;
        }
        
        if (lastPosition == 0) {
            throw new NoSuchElementException();
        }
        
        if(lastPosition == 1) {
            removeFirst();
        } else if (lastPosition == size()) {
            removelast();
        } else {
            aux = header.next;
            int j = 1;
            while(j < lastPosition) {
                aux = aux.next;
                j++;
            }
            aux.prev.next = aux.next;
            aux.next.prev = aux.prev;
            aux.prev = null;
        }
        
        return lastPosition;

	}


	@Override
	public int countElem(T elem) {
		if (elem == null) 
			throw new NullPointerException();
		
		int cont = 0;
		int i = 0;
		
		DoubleNode<T> aux = header.next;
		while (aux != header) {
			if (aux.elem.equals(elem)) {
				cont++;
			}
			i++;
			aux = aux.next;
		}
		return cont;
	}


@Override
	public IDoubleNotOrderedList<T> intersec(IDoubleNotOrderedList<T> other) {
		DoubleLinkedList<T> result = new DoubleLinkedList<>();
		DoubleNode <T> aux = header.next;
		
		if(this.isEmpty() || other.isEmpty()) {
			return result;
		}
		
		while(aux != header) {
			T elem = aux.elem;
			if (result.countElem(elem) == 0) {
				int minimun, cont = 0;
				
				if(this.countElem(elem) < other.countElem(elem)) {
					minimun = this.countElem(elem);
				} else {
					minimun = other.countElem(elem);
				}
				
				while (cont < minimun) {
					result.addLast(elem);
					cont++;
				}
			}
			aux = aux.next;
		}
		return result;
	}


	@Override
	public String fromUntilIncluded(int from, int until) {
	        StringBuilder builder = new StringBuilder();
	        int position = from;
	        if (from == 0 || until == 0) {
	            throw new IllegalArgumentException("SET");
	        } else if (from > 0 && until > 0) {
	            DoubleNode<T> aux = header.next;

	            if (from > this.size()) {
	                builder.append("()");
	            } else if (until > this.size()) {
	                int cont = 1;

	                while (cont < from) {
	                    aux = aux.next;
	                    cont++;
	                }

	                builder.append("(");
	                while (aux != header && position <= until) {
	                    builder.append(aux.elem + " ");
	                    aux = aux.next;
	                    position++;
	                }
	                builder.append(")");
	            } else {
	                int cont = 1;

	                while (cont < from) {
	                    aux = aux.next;
	                    cont++;
	                }

	                builder.append("(");
	                while (position <= until) {
	                    builder.append(aux.elem + " ");
	                    aux = aux.next;
	                    position++;
	                }
	                builder.append(")");
	            }
	        } else if (from < 0 && until < 0) {
	            DoubleNode<T> aux = header.prev;
	            if (from < -this.size() + 1) {
	                builder.append("()");
	            } else if (until < -this.size() + 1) {
	                int cont = -1;

	                while (cont > from) {

	                    aux = aux.prev;
	                    cont--;
	                }
	                builder.append("(");
	                while (aux != header && position >= until) {
	                    builder.append(aux.elem + " ");
	                    aux = aux.prev;
	                    position--;
	                }
	                builder.append(")");
	            } else {
	                int cont = -1;

	                while (cont > from) {

	                    aux = aux.prev;
	                    cont--;
	                }

	                builder.append("(");
	                while (position >= until && aux != header) {
	                    builder.append(aux.elem + " ");
	                    aux = aux.prev;
	                    position--;
	                }
	                builder.append(")");
	            }
	        } else {
	            throw new IllegalArgumentException();
	        }

	        return builder.toString();
	    
	}


	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return new CircularDoubleList_Iterator<T>(header);
	}


	@Override
	public Iterator<T> iteratorReverse() {
		// TODO Auto-generated method stub
		return new CircularDoubleList_ReverseIterator<T>(header);
	}


	@Override
	public Iterator<T> fromUntilIterator(int from, int until) {
		
		return new CircularDoubleList_FromUntilIterator(from, until, header);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append("(");

		DoubleNode<T> current = header.next;

		while (current != header) {
			sb.append(current.elem);
			sb.append(" ");
			current = current.next;
		}

		sb.append(")");
	
		return sb.toString();
	}
	
	@Override
	public String toStringReverse() {
		DoubleLinkedList<T> reversedList = new DoubleLinkedList<T>();
		DoubleNode<T> aux = header.next;
		while (aux != header) {
			reversedList.addFirst(aux.elem);
			aux = aux.next;
		}
		return reversedList.toString();
	}


	
	
}